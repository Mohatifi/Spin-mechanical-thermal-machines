

close all;
clear all;

% Load the data from the .mat file
data = load('optimalcoolingresults.mat');  % Ensure the correct file name

wm = 50 * 2 * pi;

% Extract the variables
Delta = data.Delta / wm;
g = data.g / wm;
exp3 = data.exp3;


% Determine the sizes of Delta and g
[Nd, Ng] = size(exp3);

% Observable names corresponding to the elements in exp3
observable_names = {'ad_a', 'z', 'p', 'z2', 'p2', 'a', 'a2', 'sz', 'sx', 'sy', 'H'};

% LaTeX formatted names for the observables
latex_names = {'a^\dagger a', 'z', 'p', 'z^2', 'p^2', 'a', 'a^2', 's_z', 's_x', 's_y', 'H'};

% Initialize matrices to store each observable
observables = struct();
for k = 1:length(observable_names)
    observables.(observable_names{k}) = zeros(Nd, Ng); % Initialize with zeros
end

% Extract each observable from exp3
for jj = 1:Ng
    for ii = 1:Nd
        for k = 1:length(observable_names)
            if ~isempty(exp3{ii, jj}) && length(exp3{ii, jj}) >= k
                observables.(observable_names{k})(ii, jj) = exp3{ii, jj}(k);
            else
                observables.(observable_names{k})(ii, jj) = 0; % Handle non-numeric or empty cases
            end
        end
    end
end



% Plot each observable
for k = 1:1
    figure;
    surf(Delta, g, real(observables.(observable_names{k}))/5, 'EdgeColor', 'none');
    colormap(jet);
    colorbar;
    xlabel('$\Delta / \omega_m$', 'Interpreter', 'latex');
    ylabel('$g / \omega_m$', 'Interpreter', 'latex');
    zlabel(['$', latex_names{k}, '$'], 'Interpreter', 'latex');
    title(['$\Delta / \omega_m$ vs $g / \omega_m$ vs $', latex_names{k}, '$'], 'Interpreter', 'latex');
    set(gca, 'FontSize', 14);
end

