t=readmatrix('timelist.xlsx');

Nph=readmatrix('phonon_no_cooled.xlsx');

figure
p1=plot(wm*t,Nph,'k');
p1.LineWidth=3;
xlim([0,450])
xlabel('$\omega_m t$', 'Interpreter', 'latex','FontSize',40);
ylabel('$\overline{n}$', 'Interpreter', 'latex','FontSize',40);
grid off
axis square
get(gca,'XTick');
set(gca,'FontSize',40)
set(get(gca,'ylabel'),'rotation',0)
box on
ax = gca;
ax.LineWidth=3.;
%}