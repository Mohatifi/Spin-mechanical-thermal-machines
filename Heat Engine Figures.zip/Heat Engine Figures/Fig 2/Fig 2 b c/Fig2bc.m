close all
data1=table2array(SpinBattery50Hznewdataallval)

time = data1(:,1)*50;
Zm = data1(:,3);
Szm = data1(:,4);
Ph=data1(:,2)



figure;
fixed_xticks = linspace(0, 6, 4);
fixed_yticks = linspace(0, 1, 2);
Z=Zm/max(Zm)
% First subplot (top)
subplot(2, 1, 1); % 2 rows, 1 column, first plot
% First plot (top)
plot(time, Z, 'LineWidth', 2.5,'Color','k')
xlim([0, 6.5])
ylim([-1.1, 1.1])
ylabel('$\frac{\langle z\rangle}{z_{zpf}}$','interpreter','latex','fontname', 'Times', 'FontSize', 120)
box on
ax = gca;
ax.LineWidth = 2;
xticks(ax, fixed_xticks);
%title('Dataset 1');
set(gca, 'FontSize', 20)
set(get(gca,'ylabel'),'rotation',0)
grid off;
pbaspect([1.5 0.7 1]); % Set aspect ratio: [width height depth]
%ax1.Position = [left_padding, 0.55, width, 0.4]; % [left, bottom, width, height]
subplot(2, 1, 2)
plot(time, Szm, 'LineWidth', 2.1, 'LineStyle', '-','Color','r')
xlim([0,6.5 ])
ylim([0, 1.4])

%ylabel('Y2 Axis (exp(x/10))');
ylabel('$\langle \sigma_z\rangle$','interpreter','latex','fontname', 'Times', 'FontSize', 40)

%xlabel('time');
xlabel('$\omega_m t/(2\pi)$','interpreter','latex','fontname', 'Times', 'FontSize', 30)

set(gca, 'FontSize', 30)
set(get(gca,'ylabel'),'rotation',0)

box on
ax = gca;
ax.LineWidth = 3.4;
%title('Dataset 2');
grid off;
pbaspect([1.5 0.2 1]); % Set aspect ratio: [width height depth]
xticks(ax, fixed_xticks);
yticks(ax, 0) %fixed_yticks);
%ax2.Position = [left_padding, 0.1, width, 0.4]; % [left, bottom, width, height]

% Link the x-axes (optional)
%linkaxes([ax1, ax2], 'x');
%}


figure;
fixed_xticks = linspace(0, 6, 4);
fixed_yticks = linspace(0, 1, 2);
% First subplot (top)
subplot(2, 1, 1);
plot(time, Ph, 'LineWidth', 2.5,'Color','k')
xlim([0, 6.5])

ylabel('$n(t)-n_i$','interpreter','latex','fontname', 'Times', 'FontSize', 120)
box on
ax = gca;
ax.LineWidth = 2;
xticks(ax, fixed_xticks);
%title('Dataset 1');
set(gca, 'FontSize', 20)
set(get(gca,'ylabel'),'rotation',0)
grid off;
pbaspect([1.5 0.7 1]); % Set aspect ratio: [width height depth]
%ax1.Position = [left_padding, 0.55, width, 0.4]; % [left, bottom, width, height]
subplot(2, 1, 2)
plot(time, Szm, 'LineWidth', 2.1, 'LineStyle', '-','Color','r')
xlim([0,6.5 ])
ylim([0, 1.4])

%ylabel('Y2 Axis (exp(x/10))');
ylabel('$\langle \sigma_z\rangle$','interpreter','latex','fontname', 'Times', 'FontSize', 40)

%xlabel('time');
xlabel('$\omega_m t/(2\pi)$','interpreter','latex','fontname', 'Times', 'FontSize', 30)

set(gca, 'FontSize', 30)
set(get(gca,'ylabel'),'rotation',0)

box on
ax = gca;
ax.LineWidth = 3.4;
%title('Dataset 2');
grid off;
pbaspect([1.5 0.2 1]); % Set aspect ratio: [width height depth]
xticks(ax, fixed_xticks);
yticks(ax, 0) %fixed_yticks);
%ax2.Position = [left_padding, 0.1, width, 0.4]; % [left, bottom, width, height]

% Link the x-axes (optional)
%linkaxes([ax1, ax2], 'x');
%}

