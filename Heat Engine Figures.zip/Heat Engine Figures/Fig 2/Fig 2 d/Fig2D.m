close all
data1=table2array(SpinBattery50HzEfficiency)

Dephasing=data1(:,1)
Charge = data1(:,2);
Discharge=data1(:,3)





%{figure;

fixed_xticks = linspace(0, 1, 3);
fixed_yticks = linspace(0, 1, 2);
% First subplot (top)

 %First plot (top)
plot(Dephasing/1000,Charge, 'LineWidth', 3,'Color','r','DisplayName', 'Charging')
hold on
plot(Dephasing/1000,Discharge,'LineWidth', 3,'Color','k', 'DisplayName','Discharging')

hold off
%xlim([0, 0.0004])
ylim([60, 100])
xlabel('Dephasing Rate (kHz)','interpreter','latex','fontname', 'Times', 'FontSize', 120)
ylabel('Efficiency (%)','interpreter','latex','fontname', 'Times', 'FontSize', 120)
box on
ax = gca;
ax.LineWidth = 2.7;
%xticks(ax, fixed_xticks);
%title('Dataset 1');
set(gca, 'FontSize', 30)
set(get(gca,'ylabel'),'rotation',0)

lgd = legend; % Create legend object
lgd.FontSize = 17.5; % Change font size
grid off;
pbaspect([1.5 1 1]);
%}
