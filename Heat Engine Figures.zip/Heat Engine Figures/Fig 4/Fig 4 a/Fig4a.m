
kb= 20836619120; % in hertz per Kevin
data = load('resultsh.mat');
load('Ncool.mat')
load('parama.mat')
t=load('time.mat');
t=t.time;
load('Temperature.mat')
load('ntt.mat')
load('Stt.mat')
load('time')
load('Ett.mat')
load('EnergyF.mat')
ntt=[n1t,n2t,n3t,n4t];
Stt=[s1t,s2t,s3t,s4t];
ett=[e1t,e2t,e3t,e4t];
ntts=ntt;
Stts=Stt;
etts=ett;

s4ts=s4t;
tss = linspace(0,150,38000);


N = param(1);
S = param(2);
wm = 414.1592653589793%param(3);
fx = param(4);
fy = param(5);
g = param(6);
Delta = param(7);
wt = param(8);
T = 0.0100%param(9);
tfree = param(10);
Tpy = param(11);
tlase = param(12);
Qm = param(13);
gammas = param(14);
gammaa = param(15);
gamma_l = param(16);
n_th = param(17);
sp_th_a = param(18);
ntimes = param(19);



Ei = [E_0, E_1, E_2, E_3, E_4];
Ti = [T_0, T_1, T_2, T_3, T_4];


Wc = Ei(4)-Ei(3);
Qh = Ei(1)-Ei(4);
We = Ei(2)-Ei(1);
Qc = Ei(3)-Ei(2);


wi = [65.91549430918954, 50.0, 50.0, 65.91549430918954, 65.91549430918954]
%[wm, wm-wt*T, wm-wt*T, wm, wm];
[Wc, Qh, We, Qc]


T1=Ti(3);
T3=Ti(5);
T2=Ti(4);
T4=Ti(2);

[1+Qc/Qh,-(We+Wc)/Qh,1-(T4-T1)/(T3-T2),1-T4/T3,wt*T/wm]

%%
twm=linspace(0,T,500);
tpy = linspace(0, Tpy, 50);
tf1 = linspace(0, tfree, 200);
tgl = linspace(0, tlase, 50);
% t1cycle=[tpy,tpy(end)+tf1, tpy(end)+tf1(end)+tgl];
t1cycle=[tf1, tf1(end)+tgl];

% tall=[twm,twm(end)+t,t(end)+twm(end)+twm]
t1=time(1:length(n1t));
% t2=time(length(n1t)+1:length(n1t)+length(n2t));
Gm=wm/Qm;
% t5=linspace(0,15000*Gm,10000);
t5=linspace(0,150,30000);

% Initialize cell arrays to store the results
n3k = cell(length(Ncool), 1);
S3k = cell(length(Ncool), 1);
n4k = cell(length(Ncool), 1);
S4k = cell(length(Ncool), 1);
n5k = cell(length(Ncool), 1);
S5k = cell(length(Ncool), 1);


for i=1:length(Ncool)
    ntimes = Ncool(i);
    
    % Construct variable names
    nph_name = ['nph_', num2str(ntimes)];
    EntropyM_name = ['EntropyM_', num2str(ntimes)];
    n4t_name = ['n4t_', num2str(ntimes)];
    S4t_name = ['S4t_', num2str(ntimes)];
    n5t_name = ['n5t_', num2str(ntimes)];
    S5t_name = ['S5t_', num2str(ntimes)];
    
    % Access variables
    n3k{i} = data.(nph_name);
    S3k{i} = data.(EntropyM_name);
    n4k{i} = data.(n4t_name);
    S4k{i} = data.(S4t_name);
    n5k{i} = data.(n5t_name);
    S5k{i} = data.(S5t_name);

    nttk{i}=[n1t,n3k{i},n4k{i},n5k{i}];
    Sttk{i}=[s1t,S3k{i},S4k{i},S5k{i}];

end



%%
clc
close all

wtp=(wt*(t1-T)+wm)/(2*pi);
wtm=(-wt*t1+wm)/(2*pi);
nref=[n1t,n3k{1},n4k{1},n5k{1}];
Tref=(wtm/kb)./log(1+1./(n4k{1}));
T0=Tref(1);

figure('units','normalized','outerposition',[0 0 0.5 1])
for i=1:length(Ncool)
    


    nttk{i}=[n1t,n3k{i},n4k{i},n5k{i}];
    Sttk{i}=[s1t,S3k{i},S4k{i},S5k{i}];

    T1t=(wtm/kb)./log(1+1./(n1t));
    T2t=(wtm(end)/kb)./log(1+1./(n3k{i}));
    T3t=(wtp/kb)./log(1+1./(n4k{i}));
    T4t=(wtp(end)/kb)./log(1+1./(n5k{i}));
    
    nt=nttk{i};
    Tt=[T1t,T2t,T3t,T4t];
    St=Sttk{i};
    aa{:,i}=['$N_{c}=$',num2str(Ncool(i))];


    
    figure(1)
    hold on
    plot(St,Tt/T0,'LineWidth',2)
    xlabel('$S$','interpreter','latex','fontname', 'Times','FontSize',30)
    ylabel('$T/T_c$','interpreter','latex','fontname', 'Times','FontSize',30)
    grid off
    xlim([min(St)*0.95,1.05*max(St)])
    ylim([min(Tt/T0)*0.9,1.05*max(Tt/T0)])
    axis square
    get(gca,'XTick');
    set(gca,'FontSize',28)
    set(get(gca,'ylabel'),'rotation',0)
    box on
    ax = gca;
    ax.LineWidth=2.;
    pbaspect([2 1 1])
   

end

hh=legend(aa);
set(hh, 'Interpreter','latex','fontname', 'Times','FontSize',25)
