clear all
clc
close all

kb= 20836619120; % in hertz per Kevin

data=load('energy_results_efficiency1.mat');

load('param3.mat')
wm = param3(3);
wt = param3(8);

ETl= data.ETl;
nTl=data.nTl;
Tl=data.Tl;
Lamdal=wt*Tl/wm;
etahe=[];
etar=[];
lhe=[];
lr=[];
ethal=[];
rT=zeros(1,length(Tl));
rTb=zeros(1,length(Tl));

rThe=[];
for i=1:length(Tl)
    kk=0;
    kk2=0;
    kk3=0;
    Ek = ETl(:,i);
    nk = nTl(:,i);
    wil=[wm, wm*(1-Lamdal(i)),wm*(1-Lamdal(i)),wm, wm];
    T1=(wm/kb)./log(1+1./(nk(1)));
    T2=(wm*(1-Lamdal(i))/kb)./log(1+1./(nk(2)));
    T3=(wm*(1-Lamdal(i))/kb)./log(1+1./(nk(3)));
    T4=(wm/kb)./log(1+1./(nk(4)));
    T5=(wm/kb)./log(1+1./(nk(5)));
    Tk(:,i)=[T1,T2,T3,T4,T5];

    if T2>T3
        Wc = Ek(4)-Ek(3);
        Qh = Ek(1)-Ek(4);
        We = Ek(2)-Ek(1);
        Qc = Ek(3)-Ek(2);
        etahe=[etahe, 1+Qc/Qh];
        lhe=[lhe,Lamdal(i)];
        rThe=[rThe,Tk(2,i)/Tk(1,i)];
        kk=Tk(2,i)/Tk(1,i);
        kk2=1-sqrt(Tk(2,i)/Tk(1,i));
        kk3=Tk(3,i)/Tk(4,i);
    else
        Wc = Ek(1)-Ek(2);
        Qh = Ek(4)-Ek(1);
        We = Ek(3)-Ek(4);
        Qc = Ek(2)-Ek(3);
        etar=[etar, 1+Qc/Qh];
        lr=[lr,Lamdal(i)];
        rThe=[rThe,Tk(3,i)/Tk(4,i)];
        kk=Tk(3,i)/Tk(4,i);
        kk2=1-sqrt(Tk(3,i)/Tk(4,i));
        kk3=Tk(2,i)/Tk(1,i);
    end

    Qhl(i)=Qh;
    Qcl(i)=Qc;
    Wel(i)=We;
    Wcl(i)=Wc;
    ethal=[ethal, 1+Qc/Qh];
    rT(i)=kk3;
    rTb(i)=kk3;
    rCA(i)=kk2;
      
end



figure
p1=plot(Tl,Qhl,'b');
p1.LineWidth=4;
hold on
p2=plot(Tl,Qcl,'r');
p2.LineWidth=4;
xlabel('$T$','interpreter','latex','fontname', 'Times','FontSize',30)
grid off
axis square
get(gca,'XTick');
set(gca,'FontSize',40)
set(get(gca,'ylabel'),'rotation',0)
box on
ax = gca;
ax.LineWidth=2.;
hhl=legend('$Q_h$','$Q_c$');
set(hhl, 'Interpreter','latex','fontname', 'Times','FontSize',40)





% Consistent LaTeX interpreters
set(groot,'defaultTextInterpreter','latex',...
          'defaultAxesTickLabelInterpreter','latex',...
          'defaultLegendInterpreter','latex');

% Residuals differences 
deta = ethal - Lamdal;
rms_err = sqrt(mean(deta.^2));
max_err = max(abs(deta));

figure('Color','w'); hold on; box on; axis square
p_th = plot(rT, Lamdal, '.-b', 'LineWidth',5);
p_dt = plot(rT, ethal, '--r', 'LineWidth',5);

xlabel('$T_3/T_4$','FontName','Times','FontSize',18)
ylabel('$\eta$','FontName','Times','FontSize',18)
xlim([0 1]); ylim([0 1])
xticks(0:0.2:1); yticks(0:0.2:1)
set(gca,'LineWidth',2,'FontSize',40); ax = gca; ax.TickDir='out';

leg = legend([p_th p_dt], '$\eta_C$','$\eta$',...
             'Location','southwest'); legend boxoff

% Inset: Δη
axInset = axes('Position',[.58 .63 .32 .28]); hold(axInset,'on'); box(axInset,'on')
plot(axInset, rT, deta, '-', 'LineWidth',1.5, 'Color',[.2 .2 .2])
yline(axInset, 0, ':', 'HandleVisibility','off')
xlim(axInset,[0 .9])
xticks(axInset, 0:0.2:1)
axInset.FontSize = 20;
ylabel(axInset, '$\Delta\eta$'); xlabel(axInset, '$T_3/T_4$')

% Optional: annotate error numbers
txt = sprintf('$\\mathrm{RMS} = %.2g$, $\\max = %.2g$', rms_err, max_err);
text(0.02, 0.95, txt, 'Units','normalized','Interpreter','latex','FontSize',10, 'Parent',axInset)
% High-quality export at final size
set(gcf,'Units','centimeters','Position',[2 2 12 12]) % 12x12 cm




%%


% dataa=load('energy_results_Nc.mat');
load('paramNc.mat')
dataa=load('energy_results_coolinga.mat');
wm = paramNc(3);
wt = paramNc(8);
T = paramNc(9);

ETl= dataa.ETl;
nTl=dataa.nTl;
Nc=dataa.Nc;


Lamda=wt*T/wm;
etahe=[];
etar=[];
lhe=[];
lr=[];
ethal=[];
rT=zeros(1,length(Nc));
rTb=zeros(1,length(Nc));

rThe=[];

for i=1:length(Nc)
    kk=0;
    kk2=0;
    kk3=0;
    Ek = ETl(:,i);
    nk = nTl(:,i);
    wil=[wm, wm*(1-Lamda),wm*(1-Lamda),wm, wm];
    T1=(wm/kb)./log(1+1./(nk(1)));
    T2=(wm*(1-Lamda)/kb)./log(1+1./(nk(2)));
    T3=(wm*(1-Lamda)/kb)./log(1+1./(nk(3)));
    T4=(wm/kb)./log(1+1./(nk(4)));
    T5=(wm/kb)./log(1+1./(nk(5)));
    Tk(:,i)=[T1,T2,T3,T4,T5];
    
    if T2>T3
        Wc = Ek(4)-Ek(3);
        Qh = Ek(1)-Ek(4);
        We = Ek(2)-Ek(1);
        Qc = Ek(3)-Ek(2);
        etahe=[etahe, 1+Qc/Qh];
        lhe=[lhe,Lamda];
        rThe=[rThe,Tk(2,i)/Tk(1,i)];
        kk=Tk(2,i)/Tk(1,i);
        kk2=1-sqrt(Tk(2,i)/Tk(1,i));
        kk3=Tk(3,i)/Tk(4,i);
%         disp(0)
    else
        Wc = Ek(1)-Ek(2);
        Qh = Ek(4)-Ek(1);
        We = Ek(3)-Ek(4);
        Qc = Ek(2)-Ek(3);
        etar=[etar, 1+Qc/Qh];
        lr=[lr,Lamda];
        rThe=[rThe,Tk(3,i)/Tk(4,i)];
        kk=Tk(3,i)/Tk(4,i);
        kk2=1-sqrt(Tk(3,i)/Tk(4,i));
        kk3=Tk(2,i)/Tk(1,i);
        
%         disp(1)
    end

    Qhl(i)=Qh;
    Qcl(i)=Qc;
    Wel(i)=We;
    Wcl(i)=Wc;
    ethal=[ethal, 1+Qc/Qh];
    rT(i)=kk;
    rTb(i)=kk3;
    rCA(i)=kk2;
      
end


plot(Nc,ethal/Lamda,'r','LineWidth',3)
xlabel('$N_c$','interpreter','latex','fontname', 'Times','FontSize',40)
ylabel('$\eta/\eta_C$','interpreter','latex','fontname', 'Times','FontSize',40)
grid off
axis square
get(gca,'XTick');
set(gca,'FontSize',40)
set(get(gca,'ylabel'),'rotation',0)
box on
ax = gca;
ax.LineWidth=2.5;
% xlim([0,25])
